import 'package:flutter/material.dart';
import 'package:amap_flutter_map/amap_flutter_map.dart';
import 'package:amap_flutter_base/amap_flutter_base.dart';
import '../services/map_service.dart';

class MapWidget extends StatefulWidget {
  final List<LatLng>? pathPoints;
  final bool showCurrentLocation;

  const MapWidget({
    Key? key,
    this.pathPoints,
    this.showCurrentLocation = true,
  }) : super(key: key);

  @override
  _MapWidgetState createState() => _MapWidgetState();
}

class _MapWidgetState extends State<MapWidget> {
  final MapService _mapService = MapService();

  @override
  Widget build(BuildContext context) {
    return AMapWidget(
      apiKey: _mapService.amapOptions['apiKey'] as String,
      onMapCreated: (controller) {
        _mapService.mapController = controller;

        // 如果有路径点，绘制路径
        if (widget.pathPoints != null && widget.pathPoints!.isNotEmpty) {
          _mapService.drawRidePath(widget.pathPoints!);

          // 移动到路径起点
          _mapService.moveToLocation(widget.pathPoints!.first);
        }
      },
      // 地图初始位置（北京）
      initialCameraPosition: const CameraPosition(
        target: LatLng(39.909, 116.397),
        zoom: 15,
      ),
    );
  }
}