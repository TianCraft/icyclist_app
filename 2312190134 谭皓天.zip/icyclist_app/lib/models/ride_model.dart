class RideRecord {
  String id;
  DateTime startTime;
  DateTime? endTime;
  List<LocationPoint> path;
  double totalDistance; // 公里
  double averageSpeed; // km/h
  double maxSpeed; // km/h
  Duration duration;

  RideRecord({
    required this.id,
    required this.startTime,
    this.endTime,
    required this.path,
    required this.totalDistance,
    required this.averageSpeed,
    required this.maxSpeed,
    required this.duration,
  });

  // 从JSON转换
  factory RideRecord.fromJson(Map<String, dynamic> json) {
    return RideRecord(
      id: json['id'],
      startTime: DateTime.parse(json['startTime']),
      endTime: json['endTime'] != null ? DateTime.parse(json['endTime']) : null,
      path: (json['path'] as List).map((e) => LocationPoint.fromJson(e)).toList(),
      totalDistance: json['totalDistance'],
      averageSpeed: json['averageSpeed'],
      maxSpeed: json['maxSpeed'],
      duration: Duration(seconds: json['duration']),
    );
  }

  // 转换为JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime?.toIso8601String(),
      'path': path.map((e) => e.toJson()).toList(),
      'totalDistance': totalDistance,
      'averageSpeed': averageSpeed,
      'maxSpeed': maxSpeed,
      'duration': duration.inSeconds,
    };
  }
}

class LocationPoint {
  double latitude;
  double longitude;
  double? altitude;
  double? speed;
  DateTime timestamp;

  LocationPoint({
    required this.latitude,
    required this.longitude,
    this.altitude,
    this.speed,
    required this.timestamp,
  });

  factory LocationPoint.fromJson(Map<String, dynamic> json) {
    return LocationPoint(
      latitude: json['latitude'],
      longitude: json['longitude'],
      altitude: json['altitude'],
      speed: json['speed'],
      timestamp: DateTime.parse(json['timestamp']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'latitude': latitude,
      'longitude': longitude,
      'altitude': altitude,
      'speed': speed,
      'timestamp': timestamp.toIso8601String(),
    };
  }
}