import 'package:flutter/material.dart';
import '../services/ride_service.dart';
import '../models/ride_model.dart';
import '../widgets/map_widget.dart';

class HistoryScreen extends StatefulWidget {
  @override
  _HistoryScreenState createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final RideService _rideService = RideService();
  List<RideRecord> _rides = [];
  RideRecord? _selectedRide;

  @override
  void initState() {
    super.initState();
    _loadRides();
  }

  void _loadRides() async {
    await _rideService.loadRideRecords();
    setState(() {
      _rides = _rideService.getAllRides();
      _rides.sort((a, b) => b.startTime.compareTo(a.startTime)); // 按时间倒序
    });
  }

  void _showRideDetails(RideRecord ride) {
    setState(() {
      _selectedRide = ride;
    });
  }

  void _deleteRide(String id) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除记录'),
        content: Text('确定要删除这条骑行记录吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('取消'),
          ),
          TextButton(
            onPressed: () {
              _rideService.deleteRideRecord(id);
              _loadRides();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('记录已删除')),
              );
            },
            child: Text('删除', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  String _formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    if (hours > 0) {
      return '${hours}小时${minutes}分钟';
    } else {
      return '${minutes}分钟';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('骑行记录'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: _rides.isEmpty ? _buildEmptyState() : _buildHistoryList(),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.history, size: 80, color: Colors.grey),
          SizedBox(height: 16),
          Text(
            '暂无骑行记录',
            style: TextStyle(fontSize: 18, color: Colors.grey),
          ),
          SizedBox(height: 8),
          Text(
            '开始你的第一次骑行吧！',
            style: TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryList() {
    return Column(
      children: [
        // 统计摘要
        Container(
          padding: EdgeInsets.all(16),
          color: Colors.blue.shade50,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildSummaryItem('总次数', '${_rides.length} 次'),
              _buildSummaryItem('总里程', '${_calculateTotalDistance().toStringAsFixed(1)} km'),
              _buildSummaryItem('总时长', _calculateTotalDuration()),
            ],
          ),
        ),

        // 记录列表和详情
        Expanded(
          child: Row(
            children: [
              // 列表
              Expanded(
                flex: 1,
                child: ListView.builder(
                  itemCount: _rides.length,
                  itemBuilder: (context, index) {
                    final ride = _rides[index];
                    return _buildRideItem(ride);
                  },
                ),
              ),

              // 详情
              if (_selectedRide != null)
                Expanded(
                  flex: 2,
                  child: _buildRideDetail(_selectedRide!),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSummaryItem(String title, String value) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.blue,
          ),
        ),
        Text(
          title,
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
      ],
    );
  }

  Widget _buildRideItem(RideRecord ride) {
    final isSelected = _selectedRide?.id == ride.id;

    return Card(
      margin: EdgeInsets.all(8),
      color: isSelected ? Colors.blue.shade50 : Colors.white,
      child: ListTile(
        leading: Icon(Icons.directions_bike, color: Colors.blue),
        title: Text('${ride.totalDistance.toStringAsFixed(2)} km'),
        subtitle: Text(_formatDate(ride.startTime)),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('${ride.averageSpeed.toStringAsFixed(1)} km/h'),
            IconButton(
              icon: Icon(Icons.delete, color: Colors.red),
              onPressed: () => _deleteRide(ride.id),
            ),
          ],
        ),
        onTap: () => _showRideDetails(ride),
      ),
    );
  }

  Widget _buildRideDetail(RideRecord ride) {
    return Card(
      margin: EdgeInsets.all(16),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '骑行详情',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),

            // 基本信息
            _buildDetailRow('开始时间', _formatDate(ride.startTime)),
            _buildDetailRow('结束时间', _formatDate(ride.endTime!)),
            _buildDetailRow('骑行时长', _formatDuration(ride.duration)),
            _buildDetailRow('总距离', '${ride.totalDistance.toStringAsFixed(2)} km'),
            _buildDetailRow('平均速度', '${ride.averageSpeed.toStringAsFixed(1)} km/h'),
            _buildDetailRow('最高速度', '${ride.maxSpeed.toStringAsFixed(1)} km/h'),
            _buildDetailRow('路径点数', '${ride.path.length} 个'),

            SizedBox(height: 16),
            Divider(),
            SizedBox(height: 16),

            // 地图预览
            Text(
              '骑行路径',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Expanded(
              child: MapWidget(
                pathPoints: ride.path
                    .map((point) => LatLng(point.latitude, point.longitude))
                    .toList(),
                showCurrentLocation: false,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text('$label: ', style: TextStyle(fontWeight: FontWeight.bold)),
          Text(value),
        ],
      ),
    );
  }

  double _calculateTotalDistance() {
    return _rides.fold(0.0, (sum, ride) => sum + ride.totalDistance);
  }

  String _calculateTotalDuration() {
    final totalMinutes = _rides.fold(0, (sum, ride) => sum + ride.duration.inMinutes);
    final hours = totalMinutes ~/ 60;
    final minutes = totalMinutes % 60;

    if (hours > 0) {
      return '${hours}小时${minutes}分钟';
    } else {
      return '${minutes}分钟';
    }
  }
}