import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../services/location_service.dart';
import '../services/ride_service.dart';
import '../services/map_service.dart';
import '../models/ride_model.dart';
import '../widgets/map_widget.dart';
import '../widgets/ride_stats.dart';

class RideScreen extends StatefulWidget {
  @override
  _RideScreenState createState() => _RideScreenState();
}

class _RideScreenState extends State<RideScreen> {
  final LocationService _locationService = LocationService();
  final RideService _rideService = RideService();
  final MapService _mapService = MapService();

  bool _isRiding = false;
  DateTime? _startTime;
  List<LocationPoint> _currentPath = [];
  Map<String, dynamic> _currentStats = {
    'totalDistance': 0.0,
    'averageSpeed': 0.0,
    'maxSpeed': 0.0,
    'duration': Duration.zero,
  };

  @override
  void initState() {
    super.initState();
    _initializeLocation();
  }

  void _initializeLocation() async {
    await _locationService.checkLocationPermission();
    await _locationService.getCurrentLocation();
  }

  void _startRide() {
    setState(() {
      _isRiding = true;
      _startTime = DateTime.now();
      _currentPath.clear();
      _currentStats = {
        'totalDistance': 0.0,
        'averageSpeed': 0.0,
        'maxSpeed': 0.0,
        'duration': Duration.zero,
      };
    });

    _locationService.startLocationTracking();

    // 每秒更新统计数据
    _startStatsTimer();
  }

  void _stopRide() {
    setState(() {
      _isRiding = false;
    });

    _locationService.stopLocationTracking();
    _saveRideRecord();
  }

  void _startStatsTimer() {
    // 每秒更新一次统计数据
    Future.delayed(Duration(seconds: 1), () {
      if (_isRiding) {
        _updateStats();
        _startStatsTimer();
      }
    });
  }

  void _updateStats() {
    final currentPath = _locationService.getCurrentPath();
    if (currentPath.isNotEmpty) {
      setState(() {
        _currentPath = currentPath;
        _currentStats = _rideService.calculateRideStats(currentPath);
      });
    }
  }

  void _saveRideRecord() async {
    if (_currentPath.length < 2) {
      _showMessage('骑行距离太短，未保存记录');
      return;
    }

    final rideRecord = RideRecord(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      startTime: _startTime!,
      endTime: DateTime.now(),
      path: _currentPath,
      totalDistance: _currentStats['totalDistance'],
      averageSpeed: _currentStats['averageSpeed'],
      maxSpeed: _currentStats['maxSpeed'],
      duration: _currentStats['duration'],
    );

    await _rideService.saveRideRecord(rideRecord);
    _showMessage('骑行记录已保存！');
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: Duration(seconds: 2),
      ),
    );
  }

  List<LatLng> _convertToLatLng(List<LocationPoint> path) {
    return path.map((point) => LatLng(point.latitude, point.longitude)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('骑行中'),
        backgroundColor: _isRiding ? Colors.green : Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          if (_isRiding)
            IconButton(
              icon: Icon(Icons.location_on),
              onPressed: () {
                final position = _locationService.currentPosition;
                if (position != null) {
                  _mapService.moveToLocation(
                    LatLng(position.latitude, position.longitude),
                  );
                }
              },
            ),
        ],
      ),
      body: Column(
        children: [
          // 地图区域
          Expanded(
            flex: 2,
            child: MapWidget(
              pathPoints: _convertToLatLng(_currentPath),
              showCurrentLocation: true,
            ),
          ),

          // 统计信息
          if (_isRiding && _currentPath.isNotEmpty)
            Padding(
              padding: EdgeInsets.all(16),
              child: RideStats(
                distance: _currentStats['totalDistance'],
                averageSpeed: _currentStats['averageSpeed'],
                maxSpeed: _currentStats['maxSpeed'],
                duration: _currentStats['duration'],
              ),
            ),

          // 控制按钮
          Container(
            padding: EdgeInsets.all(16),
            child: _isRiding ? _buildRidingControls() : _buildStartControls(),
          ),
        ],
      ),
    );
  }

  Widget _buildStartControls() {
    return Column(
      children: [
        Text(
          '准备开始骑行',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          height: 60,
          child: ElevatedButton(
            onPressed: _startRide,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.play_arrow, size: 30, color: Colors.white),
                SizedBox(width: 12),
                Text(
                  '开始骑行',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRidingControls() {
    return Column(
      children: [
        Text(
          '骑行进行中...',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.green,
          ),
        ),
        SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 60,
                child: ElevatedButton(
                  onPressed: _stopRide,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.stop, size: 30, color: Colors.white),
                      SizedBox(width: 12),
                      Text(
                        '结束骑行',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 8),
        Text(
          '已记录 ${_currentPath.length} 个位置点',
          style: TextStyle(color: Colors.grey),
        ),
      ],
    );
  }

  @override
  void dispose() {
    if (_isRiding) {
      _locationService.stopLocationTracking();
    }
    super.dispose();
  }
}