import 'package:flutter/material.dart';
import 'ride_screen.dart';
import 'history_screen.dart';
import '../services/ride_service.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final RideService _rideService = RideService();
  int _totalRides = 0;
  double _totalDistance = 0.0;

  @override
  void initState() {
    super.initState();
    _loadRideData();
  }

  void _loadRideData() async {
    await _rideService.loadRideRecords();
    final rides = _rideService.getAllRides();

    setState(() {
      _totalRides = rides.length;
      _totalDistance = rides.fold(0.0, (sum, ride) => sum + ride.totalDistance);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'iCyclist',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.blue, Colors.lightBlue.shade100],
          ),
        ),
        child: Column(
          children: [
            // 统计卡片
            Container(
              margin: EdgeInsets.all(16),
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildStatCard('总骑行', '$_totalRides 次', Icons.directions_bike),
                  _buildStatCard('总里程', '${_totalDistance.toStringAsFixed(1)} km', Icons.flag),
                ],
              ),
            ),

            // 功能按钮
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // 开始骑行按钮
                    _buildActionButton(
                      '开始骑行',
                      Icons.play_arrow,
                      Colors.green,
                          () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => RideScreen()),
                        );
                      },
                    ),
                    SizedBox(height: 20),

                    // 历史记录按钮
                    _buildActionButton(
                      '骑行记录',
                      Icons.history,
                      Colors.orange,
                          () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => HistoryScreen()),
                        );
                      },
                    ),
                    SizedBox(height: 20),

                    // 个人资料按钮
                    _buildActionButton(
                      '个人资料',
                      Icons.person,
                      Colors.purple,
                          () {
                        _showProfileDialog();
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon) {
    return Column(
      children: [
        Icon(icon, size: 40, color: Colors.blue),
        SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.blue,
          ),
        ),
        Text(
          title,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey,
          ),
        ),
      ],
    );
  }

  Widget _buildActionButton(String text, IconData icon, Color color, VoidCallback onPressed) {
    return SizedBox(
      width: double.infinity,
      height: 80,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 8,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 30, color: Colors.white),
            SizedBox(width: 12),
            Text(
              text,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showProfileDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('个人资料'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('总骑行次数: $_totalRides'),
            Text('总骑行里程: ${_totalDistance.toStringAsFixed(1)} km'),
            SizedBox(height: 16),
            Text('iCyclist v1.0.0', style: TextStyle(color: Colors.grey)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('关闭'),
          ),
        ],
      ),
    );
  }
}