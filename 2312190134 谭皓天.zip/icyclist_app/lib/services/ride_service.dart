import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/ride_model.dart';

class RideService {
  static final RideService _instance = RideService._internal();
  factory RideService() => _instance;
  RideService._internal();

  static const String _rideRecordsKey = 'ride_records';
  List<RideRecord> _rides = [];

  // 加载历史记录
  Future<void> loadRideRecords() async {
    final prefs = await SharedPreferences.getInstance();
    final String? ridesJson = prefs.getString(_rideRecordsKey);

    if (ridesJson != null) {
      final List<dynamic> ridesList = json.decode(ridesJson);
      _rides = ridesList.map((e) => RideRecord.fromJson(e)).toList();
    }
  }

  // 保存骑行记录
  Future<void> saveRideRecord(RideRecord record) async {
    _rides.add(record);
    await _saveToStorage();
  }

  // 获取所有骑行记录
  List<RideRecord> getAllRides() {
    return List.from(_rides);
  }

  // 删除骑行记录
  Future<void> deleteRideRecord(String id) async {
    _rides.removeWhere((ride) => ride.id == id);
    await _saveToStorage();
  }

  // 保存到本地存储
  Future<void> _saveToStorage() async {
    final prefs = await SharedPreferences.getInstance();
    final String ridesJson = json.encode(
      _rides.map((ride) => ride.toJson()).toList(),
    );
    await prefs.setString(_rideRecordsKey, ridesJson);
  }

  // 计算统计数据
  Map<String, dynamic> calculateRideStats(List<LocationPoint> path) {
    if (path.length < 2) {
      return {
        'totalDistance': 0.0,
        'averageSpeed': 0.0,
        'maxSpeed': 0.0,
        'duration': Duration.zero,
      };
    }

    double totalDistance = 0.0;
    double totalSpeed = 0.0;
    double maxSpeed = 0.0;

    for (int i = 1; i < path.length; i++) {
      final previous = path[i - 1];
      final current = path[i];

      // 计算距离
      final distance = _calculateDistance(
        previous.latitude,
        previous.longitude,
        current.latitude,
        current.longitude,
      );
      totalDistance += distance;

      // 计算速度
      if (current.speed != null && current.speed! > 0) {
        totalSpeed += current.speed!;
        if (current.speed! > maxSpeed) {
          maxSpeed = current.speed!;
        }
      }
    }

    final duration = path.last.timestamp.difference(path.first.timestamp);
    final averageSpeed = totalSpeed / (path.length - 1);

    return {
      'totalDistance': totalDistance / 1000, // 转换为公里
      'averageSpeed': averageSpeed * 3.6, // m/s 转换为 km/h
      'maxSpeed': maxSpeed * 3.6,
      'duration': duration,
    };
  }

  double _calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const double earthRadius = 6371000; // 米

    final double dLat = _toRadians(lat2 - lat1);
    final double dLon = _toRadians(lon2 - lon1);

    final double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(_toRadians(lat1)) *
            Math.cos(_toRadians(lat2)) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);

    final double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return earthRadius * c;
  }

  double _toRadians(double degree) {
    return degree * Math.pi / 180;
  }
}