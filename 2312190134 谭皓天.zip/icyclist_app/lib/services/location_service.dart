import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/ride_model.dart';

class LocationService {
  static final LocationService _instance = LocationService._internal();
  factory LocationService() => _instance;
  LocationService._internal();

  bool _isTracking = false;
  Position? _currentPosition;
  List<LocationPoint> _currentPath = [];

  // 检查位置权限
  Future<bool> checkLocationPermission() async {
    final status = await Permission.locationWhenInUse.status;
    if (status.isGranted) {
      return true;
    } else {
      final result = await Permission.locationWhenInUse.request();
      return result.isGranted;
    }
  }

  // 获取当前位置
  Future<Position?> getCurrentLocation() async {
    try {
      final hasPermission = await checkLocationPermission();
      if (!hasPermission) return null;

      _currentPosition = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
      );
      return _currentPosition;
    } catch (e) {
      print('获取位置失败: $e');
      return null;
    }
  }

  // 开始位置跟踪
  void startLocationTracking() {
    _isTracking = true;
    _currentPath.clear();

    const LocationSettings locationSettings = LocationSettings(
      accuracy: LocationAccuracy.best,
      distanceFilter: 10, // 每10米更新一次
    );

    Geolocator.getPositionStream(locationSettings: locationSettings)
        .listen((Position position) {
      if (_isTracking) {
        _currentPosition = position;

        // 记录路径点
        _currentPath.add(LocationPoint(
          latitude: position.latitude,
          longitude: position.longitude,
          altitude: position.altitude,
          speed: position.speed,
          timestamp: DateTime.now(),
        ));
      }
    });
  }

  // 停止位置跟踪
  void stopLocationTracking() {
    _isTracking = false;
  }

  // 获取当前路径
  List<LocationPoint> getCurrentPath() {
    return List.from(_currentPath);
  }

  // 获取当前位置
  Position? get currentPosition => _currentPosition;

  // 计算两点间距离（米）
  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    return Geolocator.distanceBetween(lat1, lon1, lat2, lon2);
  }
}