import 'package:amap_flutter_map/amap_flutter_map.dart';
import 'package:amap_flutter_base/amap_flutter_base.dart';

class MapService {
  static final MapService _instance = MapService._internal();
  factory MapService() => _instance;
  MapService._internal();

  // 高德地图控制器
  AMapController? mapController;

  // 初始化地图配置
  final Map<String, Object> amapOptions = {
    'apiKey': '你的高德API_KEY', // 替换为你的实际Key
    'iOS': '你的iOS_API_KEY', // 可以先留空
  };

  // 创建地图widget
  AMapWidget createMapWidget() {
    return AMapWidget(
      apiKey: amapOptions['apiKey'] as String,
      onMapCreated: (controller) {
        mapController = controller;
      },
    );
  }

  // 绘制骑行路径
  void drawRidePath(List<LatLng> path) {
    if (mapController == null) return;

    final Polyline polyline = Polyline(
      width: 8,
      color: Colors.blue.withOpacity(0.7),
      points: path,
    );

    // 添加到地图
    mapController?.addPolyline(polyline);
  }

  // 移动到指定位置
  void moveToLocation(LatLng location) {
    mapController?.moveCamera(
      CameraUpdate.newLatLng(location),
    );
  }

  // 清空地图覆盖物
  void clearMap() {
    mapController?.clear();
  }
}