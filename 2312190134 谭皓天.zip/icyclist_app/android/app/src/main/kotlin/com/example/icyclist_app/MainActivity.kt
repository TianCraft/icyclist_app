package com.example.icyclist_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
